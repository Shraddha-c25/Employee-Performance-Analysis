# INX Future Inc. Employee Performance Analysis

Open the notebooks under `src/` in the following order:
1. `Data Processing/data_processing.ipynb`
2. `Data Processing/data_exploratory_analysis.ipynb`
3. `models/train_model.ipynb`
4. `models/predict_model.ipynb`
5. `visualization/visualize.ipynb`

See `Project Summary/Summary/project_summary.md` for the executive summary.
