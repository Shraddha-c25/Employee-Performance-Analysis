# Results, Analysis and Insights

## Key findings
- Highest average department performance: **Development (3.086)**
- Lowest average department performance: **Finance (2.776)**
- Strongest predictive factor: **EmpLastSalaryHikePercent**
- Second: **EmpEnvironmentSatisfaction**
- Third: **YearsSinceLastPromotion**
- Final model accuracy: **94.58**
- Final model F1 Score: **94.43**

## Important caution
Feature importance indicates predictive usefulness in this dataset. It should not be interpreted as causal evidence. The dataset and project brief do not establish that changing a factor will necessarily cause performance to change.

## Business answer
The analysis supports a targeted, employee-friendly approach: improve the work environment, examine compensation progression, and strengthen career progression mechanisms while using predictive analytics to identify employees who may need support. This aligns with the project requirement to identify non-performing employees without unnecessarily affecting overall employee morale.
