# Results, Analysis and Insights

## Key findings
- Highest average department performance: **Development (3.086)**
- Lowest average department performance: **Finance (2.776)**
- Strongest predictive factor: **EmpEnvironmentSatisfaction**
- Second: **EmpLastSalaryHikePercent**
- Third: **YearsSinceLastPromotion**
- Final model accuracy: **0.908**
- Final model weighted F1: **0.904**
- Final model macro F1: **0.849**

## Important caution
Feature importance indicates predictive usefulness in this dataset. It should not be interpreted as causal evidence. The dataset and project brief do not establish that changing a factor will necessarily cause performance to change.

## Business answer
The analysis supports a targeted, employee-friendly approach: improve the work environment, examine compensation progression, and strengthen career progression mechanisms while using predictive analytics to identify employees who may need support. This aligns with the project requirement to identify non-performing employees without unnecessarily affecting overall employee morale.
