# Requirement

## Source
IABAC CDS Project 2 — Employee Performance Analysis, Project Code 10281.

## Required insights
1. Department-wise performances.
2. Top 3 important factors affecting employee performance.
3. A trained model that predicts employee performance from input factors.
4. Recommendations to improve employee performance based on the analysis.

## Submission structure
The supplied IABAC guidelines require Jupyter notebooks and the directory structure used in this project: Project Summary, data (external/processed/raw), src (Data Processing/models/visualization), and references.
