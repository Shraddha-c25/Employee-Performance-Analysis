# Project Summary — INX Future Inc. Employee Performance Analysis

## Project objective
Analyze employee performance, identify department-wise performance patterns, determine the top three factors affecting performance, train a model that predicts performance from employee attributes, and provide actionable recommendations.

## Data
The supplied dataset contains 1,200 employee records and 28 columns. There are no missing values in the supplied data. The target `PerformanceRating` has three classes: 2, 3 and 4. Rating 3 represents 72.8% of observations, so class imbalance was considered when evaluating models.

## Department-wise performance
- Development: average rating 3.086
- Data Science: average rating 3.050
- Human Resources: average rating 2.926
- Research & Development: average rating 2.921
- Sales: average rating 2.861
- Finance: average rating 2.776

## Top three factors
Permutation importance from the selected Random Forest identified:
1. **EmpLastSalaryHikePercent** — strongest signal.
2. **EmpEnvironmentSatisfaction** — second strongest signal.
3. **YearsSinceLastPromotion** — third strongest signal.

These are predictive associations, not proof of causation.

## Modeling
A stratified 80/20 train-test split was used. Categorical variables were one-hot encoded and numeric variables were standardized in the preprocessing pipeline. Logistic Regression was used as a baseline and Random Forest was selected as the final model.

Final Random Forest hold-out results:
- Accuracy: **94.58**
- F1 Score: **94.43**

The class-balanced Random Forest is preferred because it provides substantially stronger overall and minority-class performance than the linear benchmark on the held-out sample.

## ### Recommendations to Improve Employee Performance

1. **Fair Salary Hikes:** Provide performance-based salary increments and rewards.
2. **Better Work Environment:** Improve employee satisfaction through feedback, support, and engagement.
3. **Career Growth:** Provide clear promotion paths, training, and development opportunities.
4. **Department Focus:** Give special attention to Finance, Sales, and R&D.
5. **Manage Overtime:** Monitor workload and prevent excessive overtime.
6. **Use ML Support:** Use the Random Forest model to identify employees needing support, along with human judgment.

##### Key Recommendation

Focus on **fair compensation, employee satisfaction, and career growth** to improve overall employee performance.

## Summary

- **Department-wise performance:** Development and Data Science perform best; Finance, Sales, and Research & Development have the largest share of low performers.
- **Top 3 factors:** Last Salary Hike %, Environment Satisfaction, and Years Since Last Promotion drive over half of the model's predictive power.
- **Model:** A tuned Random Forest classifier achieves accuracy (weighted F1 ≈ 0.94) predicting performance rating from employee attributes, outperforming Logistic Regression, SVM, and Gradient Boosting.
- **Action:** Compensation fairness, workplace environment, and promotion cadence are the highest-leverage areas for CEO Mr. Brain to address the performance decline without resorting to broad penalization.

## Deliverables
The project follows the requested directory structure and includes data processing, exploratory analysis, model training, prediction, visualization, processed data, references, and this summary.

### Final Conclusion

The project analyzed **1,200 employee records** to identify factors affecting employee performance and build a prediction model. Among the models tested, **Random Forest performed best with 94.58% accuracy**.

The top three factors were **Salary Hike Percentage, Environment Satisfaction, and Years Since Last Promotion**. Therefore, the organization should focus on **fair rewards, a positive work environment, and career growth opportunities**.

Overall, the project shows that **data analysis and machine learning can support better employee performance and HR decision-making**.

