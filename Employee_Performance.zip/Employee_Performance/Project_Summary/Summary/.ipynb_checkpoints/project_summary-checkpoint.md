# Project Summary — INX Future Inc. Employee Performance Analysis

## Project objective
Analyze employee performance, identify department-wise performance patterns, determine the top three factors affecting performance, train a model that predicts performance from employee attributes, and provide actionable recommendations.

## Data
The supplied dataset contains 1,200 employee records and 28 columns. There are no missing values in the supplied data. The target `PerformanceRating` has three classes: 2, 3 and 4. Rating 3 represents 72.8% of observations, so class imbalance was considered when evaluating models.

## Department-wise performance
- Development: average rating 3.086
- Data Science: average rating 3.050
- Human Resources: average rating 2.926
- Research & Development: average rating 2.921
- Sales: average rating 2.861
- Finance: average rating 2.776

## Top three factors
Permutation importance from the selected Random Forest identified:
1. **EmpEnvironmentSatisfaction** — strongest signal.
2. **EmpLastSalaryHikePercent** — second strongest signal.
3. **YearsSinceLastPromotion** — third strongest signal.

These are predictive associations, not proof of causation.

## Modeling
A stratified 80/20 train-test split was used. Categorical variables were one-hot encoded and numeric variables were standardized in the preprocessing pipeline. Logistic Regression was used as a baseline and Random Forest was selected as the final model.

Final Random Forest hold-out results:
- Accuracy: **0.908**
- Weighted F1: **0.904**
- Macro F1: **0.849**

The class-balanced Random Forest is preferred because it provides substantially stronger overall and minority-class performance than the linear benchmark on the held-out sample.

## Recommendations
1. Monitor and improve employee environment satisfaction through manager feedback loops, workload reviews, team climate checks, and targeted interventions.
2. Review salary-hike practices for consistency and transparency; identify high-performing employees whose compensation progression may be lagging.
3. Create promotion-readiness and career-path reviews, especially for employees with long periods since their last promotion.
4. Use department-level dashboards to track rating mix rather than relying only on a single average.
5. Use the model as a decision-support tool for hiring and workforce planning, not as the sole basis for employment decisions. Validate the model on new data before operational deployment and monitor for drift and fairness.

## Deliverables
The project follows the requested directory structure and includes data processing, exploratory analysis, model training, prediction, visualization, processed data, references, and this summary.
